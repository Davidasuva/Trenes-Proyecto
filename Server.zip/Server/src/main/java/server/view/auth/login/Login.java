package server.view.auth.login;

import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.stage.Stage;
import server.model.observer.Observer;
import server.model.observer.Subject;

import java.io.IOException;

public class Login extends Observer {

    public Login(Subject subject) {
        super(subject);
    }

    public static void show(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(
                Login.class.getResource("Login.fxml")
        );

        Parent root = loader.load();
        Scene scene = new Scene(root, 720, 480);

        java.net.URL cssUrl = Login.class.getResource("Login.css");
        if (cssUrl != null) {
            scene.getStylesheets().add(cssUrl.toExternalForm());
        }

        stage.setTitle("trenes — Iniciar sesión");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.centerOnScreen();
        stage.show();
    }

    @Override
    public void update() {

    }
}