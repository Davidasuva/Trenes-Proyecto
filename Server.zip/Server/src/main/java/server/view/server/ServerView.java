package server.view.server;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import server.controller.ServerController;
import server.model.ServerModel;

public class ServerView {

    private Parent root;
    private ServerController controller;

    public ServerView(ServerModel model) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/server/view/server/Server.fxml")
            );

            this.root = loader.load();
            this.controller = loader.getController();

            controller.setModel(model);

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error cargando ServerView");
        }
    }

    public Parent getView() {
        return root;
    }

    public ServerController getController() {
        return controller;
    }
}