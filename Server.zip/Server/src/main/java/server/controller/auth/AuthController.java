package server.controller.auth;
import javafx.animation.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.Duration;
import server.controller.ServerController;
import server.factory.ServerFactory;
import server.model.ServerModel;
import server.model.user.AbstractUser;
import server.model.user.Admin;
import server.model.user.UserService;

import java.io.IOException;

public class AuthController {

    UserService userService;

    @FXML private TextField     txtUsuario;
    @FXML private PasswordField txtPassword;
    @FXML private TextField     txtPasswordVisible;
    @FXML private Label         lblError;
    @FXML private Button        btnOjo;
    @FXML private Button        btnIngresar;
    @FXML private Label         lblCrearCuenta;

    private boolean passwordVisible = false;

    @FXML
    public void initialize() {
        try {
            userService = new UserService();
            userService.register(new Admin("0","Admin@project.com","Admin123","Apellido Culero","1234","C.C","cr 29#92-49",3));

        } catch (Exception e) {
            e.printStackTrace();
        }
        txtPassword.textProperty().addListener((obs, o, n) -> {
            if (!passwordVisible) txtPasswordVisible.setText(n);
        });
        txtPasswordVisible.textProperty().addListener((obs, o, n) -> {
            if (passwordVisible) txtPassword.setText(n);
        });
        txtUsuario.setOnAction(e -> txtPassword.requestFocus());
        txtPassword.setOnAction(e -> handleLogin());
        txtPasswordVisible.setOnAction(e -> handleLogin());
    }

    @FXML
    public void handleTogglePassword() {
        passwordVisible = !passwordVisible;
        txtPassword.setVisible(!passwordVisible);
        txtPasswordVisible.setVisible(passwordVisible);
        btnOjo.setText(passwordVisible ? "🙈" : "👁");
        if (passwordVisible) {
            txtPasswordVisible.setText(txtPassword.getText());
            txtPasswordVisible.requestFocus();
            txtPasswordVisible.positionCaret(txtPasswordVisible.getText().length());
        } else {
            txtPassword.setText(txtPasswordVisible.getText());
            txtPassword.requestFocus();
        }
    }

    @FXML
    public void handleLogin() {
        String mail  = txtUsuario.getText().trim();
        String password = passwordVisible
                ? txtPasswordVisible.getText()
                : txtPassword.getText();

        if (mail.isEmpty()) {
            mostrarError("Ingresa tu mail.");
            sacudir(txtUsuario);
            return;
        }
        if (password.isEmpty()) {
            mostrarError("Ingresa tu contraseña.");
            sacudir(txtPassword);
            return;
        }
        try {
            AbstractUser user = userService.userPerEmailAndPassword(mail, password, null);

            if (user != null) {
                lblError.setVisible(false);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Acceso concedido");
                alert.setHeaderText(null);
                alert.setContentText("¡Bienvenido, " + user.getName() + "!");
                alert.showAndWait();
                abrirServerView();
            } else {
                mostrarError("Credenciales incorrectas");
                sacudir(btnIngresar);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void mostrarError(String msg) {
        lblError.setText(msg);
        lblError.setVisible(true);
        FadeTransition ft = new FadeTransition(Duration.millis(200), lblError);
        ft.setFromValue(0); ft.setToValue(1);
        ft.play();
    }

    private void sacudir(Node n) {
        TranslateTransition tt = new TranslateTransition(Duration.millis(55), n);
        tt.setFromX(0); tt.setByX(6);
        tt.setCycleCount(6); tt.setAutoReverse(true);
        tt.play();
    }
    private void abrirServerView() {
        try {
            Parent root = ServerFactory.create();

            Stage stage = (Stage) btnIngresar.getScene().getWindow();
            stage.setScene(new Scene(root, 400, 300));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}