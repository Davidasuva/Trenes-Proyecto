package server.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import server.model.ServerModel;
import server.model.history.History;

import java.rmi.server.UnicastRemoteObject;

public class ServerController {

    @FXML private Label lblStatus;
    @FXML private Button btnDeploy;

    private ServerModel model;
    private History history;

    public void setModel(ServerModel model) {
        this.model = model;
    }

    @FXML
    public void handleDeploy() {
        btnDeploy.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                Stage stage = (Stage) newScene.getWindow();

                stage.setOnCloseRequest(event -> {
                    shutdownServer();
                });
            }
        });
        if (model.deploy()) {
            lblStatus.setText("Status: Running");
            btnDeploy.setDisable(true);
        } else {
            lblStatus.setText("Failed to deploy");
        }
    }
