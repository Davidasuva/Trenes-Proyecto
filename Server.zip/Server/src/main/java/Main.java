
import server.view.auth.login.Login;
import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Login.show(stage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
